module.exports = Object.freeze({
    PORT: 8080,
    //DB: 'mongodb+srv://rakesh:P@ssword@2021@tapp-cluster.phb4k.mongodb.net/Tapp?retryWrites=true&w=majority',
   // DB: 'mongodb+srv://vaishalijain:Welcome12345@cluster0.ffnoj.mongodb.net/TerraGrok?retryWrites=true&w=majority',
   DB: 'mongodb+srv://terra_grok:xJ0ijuLl7mEsRf4t@cluster0.o4ybz.mongodb.net/TerraGrok',
   //DB: 'mongodb+srv://vaishalidev2307:Welcome%2312345@cluster0.o34byls.mongodb.net/TerraGrok',
    API_VERSION: '1'
});